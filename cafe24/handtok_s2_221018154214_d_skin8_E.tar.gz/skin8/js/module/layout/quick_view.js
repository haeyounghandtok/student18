(function($){
    $.fn.extend({
        center: function() {
            this.each(function() {
                var
                    $this = $(this),
                    $w = $(window);
                $this.css({
                    position: "absolute",
                    top: ~~(($w.height() - $this.outerHeight()) / 2) + $w.scrollTop() + "px",
                    left: ~~(($w.width() - $this.outerWidth()) / 2) + $w.scrollLeft() + "px"
                });
            });
            return this;
        }
    });
    $(function() {
        var $container = function(){/*
    <div id="modalContainer">
        <iframe id="modalContent" scroll="0" scrolling="no" frameBorder="0"></iframe>
    </div>');
    */}.toString().slice(14,-3);
        $('body')
        .append($('<div id="modalBackpanel"></div>'))
        .append($($container));
        function closeModal () {
            $('#modalContainer').hide();
            $('#modalBackpanel').hide();
        }
        $('#modalBackpanel').on('click', closeModal);
        zoom = function ($piProductNo, $piCategoryNo, $piDisplayGroup) {
            var $url = '/product/image_zoom.html?product_no=' + $piProductNo + '&cate_no=' + $piCategoryNo + '&display_group=' + $piDisplayGroup;
            $('#modalContent').attr('src', $url);
            $('#modalContent').on("load",function(){
                $(".header .close",this.contentWindow.document.body).on("click", closeModal);
            });
            $('#modalBackpanel').css({width:$("body").width(),height:$("body").height(),opacity:.4}).show();
            $('#modalContainer').center().show();
        }
    });
})(jQuery);