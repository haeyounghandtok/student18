$(function(){
    $('[id^="replyArea_"]').each(function(e) {
        $(this).hide();
    });
});